# ShapeMaker
An interactive learning tool for kids.

<h3>Screenshots</h3>
<img src='https://i.imgur.com/auzvh75.jpg' />
<img src='https://i.imgur.com/7qLLw6R.jpg' />
